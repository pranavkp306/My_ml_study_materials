This repository contains machine learning projects and notebooks for the course of [CloudxLab](https://CloudxLab.com/)
Feel free to checkout and explore.

### NOTE ABOUT THE Notebook Diff:

Usually the jupyter notebooks are unfriendly to diff. So, we have installed nbdime(See https://nbdime.readthedocs.io/en/latest/)

All you need to do to enable in git this:
	export PATH=/usr/local/anaconda/bin:$PATH
	cd ml
	nbdime config-git --enable

To know more about us [click here](https://CloudxLab.com/)
