This directory contains model checkpoints
