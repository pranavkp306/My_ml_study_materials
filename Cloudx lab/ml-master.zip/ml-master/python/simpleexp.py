x = 10
x = x + 2
print(x)
