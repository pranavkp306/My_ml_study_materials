print("hello")
print(3+4)
